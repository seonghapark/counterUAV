#!/usr/bin/env python3
import rospy
import librosa
import numpy as np
from ros_counteruav.msg import wav

samplingrate = 5862
hz = 0.5

def binary():
    rospy.init_node('binary', anonymous=True)
    rate = rospy.Rate(hz) # 1hz    
    print('sender ready')
    file_name = '/home/project/counterUAV/ROS_system/catkin_ws/src/ros_counteruav/scripts/yeom/wav/car_1034.wav'
    Y, sr = librosa.load(file_name, sr=samplingrate, mono=False)
    print(type(Y))
    print(type(Y[0]))
    tmp = []
    for i in range(0,len(Y)):
        tmp.append(float(Y[i]))
    print(len(tmp))
    print(type(tmp))
    print(type(tmp[0]))
    message = wav()
    message.wavdata = tmp
    message.samplerate = sr
    tag = file_name.split('_')[0]
    message.info = tag
    wav_send = rospy.Publisher('wav_send', wav, queue_size=1)
    for i in range(0,10):
        print('{} send'.format(i))
        wav_send.publish(message)
        rate.sleep()

if __name__ == "__main__":
    binary()