#!/usr/bin/env python3
import rospy
import librosa
import numpy as np
from scipy.io import wavfile
from ros_counteruav.msg import wav

hz = 0.5
def callback(msg):
    print(len(msg.wavdata))
    print(msg.samplerate)
    print(msg.info)
    wavname = msg.info + ".wav"
    audio = msg.wavdata
    librosa.output.write_wav(wavname, audio, msg.samplerate, norm=False)#saved mono

def wavrec():
    print('receiver ready')
    rospy.init_node('wavrec', anonymous=True)
    rospy.Subscriber('wav_send', wav, callback)
    rospy.spin()

if __name__ == "__main__":
    wavrec()